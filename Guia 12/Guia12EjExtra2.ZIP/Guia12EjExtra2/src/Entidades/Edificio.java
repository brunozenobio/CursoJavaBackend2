/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author meluf
 */
public abstract class Edificio {
    protected Double ancho;
    protected Double largo;
    protected Double alto;

    public Edificio() {
    }

    public Edificio(Double ancho, Double largo, Double alto) {
        this.ancho = ancho;
        this.largo = largo;
        this.alto = alto;
    }

    public Double getAncho() {
        return ancho;
    }

    public void setAncho(Double ancho) {
        this.ancho = ancho;
    }

    public Double getLargo() {
        return largo;
    }

    public void setLargo(Double largo) {
        this.largo = largo;
    }

    public Double getAlto() {
        return alto;
    }

    public void setAlto(Double alto) {
        this.alto = alto;
    }
    
    public abstract Double calcularSuperficie();
        //return this.ancho * this.largo;
    
    
    public abstract Double calcularVolumen();
        //return this.alto * (this.ancho * this.largo);
    
    
}
