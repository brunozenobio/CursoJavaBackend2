/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.util.Scanner;

/**
 *
 * @author meluf
 */
public class EdificioDeOficinas extends Edificio{
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    protected Integer numOficinas;
    protected Integer cantPersonas;
    protected Integer numPisos;

    public EdificioDeOficinas() {
    }

    public EdificioDeOficinas(Integer numOficinas, Integer cantPersonas, Integer numPisos) {
        this.numOficinas = numOficinas;
        this.cantPersonas = cantPersonas;
        this.numPisos = numPisos;
    }

    public EdificioDeOficinas(Integer numOficinas, Integer cantPersonas, Integer numPisos, Double ancho, Double largo, Double alto) {
        super(ancho, largo, alto);
        this.numOficinas = numOficinas;
        this.cantPersonas = cantPersonas;
        this.numPisos = numPisos;
    }

    public Integer getNumOficinas() {
        return numOficinas;
    }

    public void setNumOficinas(Integer numOficinas) {
        this.numOficinas = numOficinas;
    }

    public Integer getCantPersonas() {
        return cantPersonas;
    }

    public void setCantPersonas(Integer cantPersonas) {
        this.cantPersonas = cantPersonas;
    }

    public Integer getNumPisos() {
        return numPisos;
    }

    public void setNumPisos(Integer numPisos) {
        this.numPisos = numPisos;
    }
    
    

   @Override
    public Double calcularSuperficie() {
      return this.ancho * this.largo;  
    }

    @Override
    public Double calcularVolumen() {
      return this.alto * (this.ancho * this.largo);
    }
    
    
    public void calcularPersonas(){
        
//        System.out.println("Ingrese la cantidad de personas que entran en cada oficina:"); 
//        this.cantPersonas = leer.nextInt();
//        System.out.println("Ingrese la cantidad de oficinas:");
//        this.numOficinas = leer.nextInt();
//        System.out.println("Ingrese la cantidad de pisos:"); 
//        this.numPisos = leer.nextInt();
//        System.out.println("Ingrese el número de piso:"); 
          int piso = leer.nextInt();
//        
        
        System.out.println("El piso: " + piso + " tiene capacidad para " + (cantPersonas*numOficinas) + " personas" );
        System.out.println("El edificio tiene capacidad para " + (cantPersonas*numOficinas*numPisos) + " personas" );
        
        
    }
}
