/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package guia12ejextra2;

import Entidades.Edificio;
import Entidades.EdificioDeOficinas;
import Entidades.Polideportivo;
import java.util.ArrayList;

/**
 *
 * @author meluf
 */
public class Guia12EjExtra2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     int cont1 =0;
     int cont2 =0;
     
     ArrayList <Edificio> edificio = new ArrayList<>();
     edificio.add(new Polideportivo("Rojo", true, 20d, 15d, 50d));
     edificio.add(new Polideportivo("Azul", false, 25d, 10d, 40d));
     edificio.add(new EdificioDeOficinas(5, 20, 4, 10d, 5d, 20d));
     edificio.add(new EdificioDeOficinas(2, 10, 5, 5d, 10d, 20d));
     
        for (Edificio edificio1 : edificio) {
            if (edificio1 instanceof Polideportivo) {
            System.out.println("El volumen del edificio es : " + edificio1.calcularVolumen());
            System.out.println("La superficie del edificio es: " + edificio1.calcularSuperficie());
            System.out.println("El edificio es techado: " + ((Polideportivo) edificio1).isTechado());
                if (((Polideportivo) edificio1).isTechado()) {
                cont1++;    
                }else{
                cont2++;    
                }
                
            }
            if (edificio1 instanceof EdificioDeOficinas) {           
            System.out.println("El volumen del edificio es : " + edificio1.calcularVolumen());
            System.out.println("La superficie del edificio es: " + edificio1.calcularSuperficie());
            ((EdificioDeOficinas) edificio1).calcularPersonas();
                System.out.println("");
            }
            
        }
        System.out.println("La cantidad de edificios techados es: " + cont1);
        System.out.println("La cantidad de edificios sin techar es: " + cont2);
     
    }
    
}
